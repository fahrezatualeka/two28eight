
    <div class="container mx-auto p-4">
        {{-- ✅ PENTING: Panggil komponen Livewire di sini --}}
        @livewire('test-api')
    </div>