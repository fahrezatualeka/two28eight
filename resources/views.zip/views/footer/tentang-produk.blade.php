@extends('layouts.app')

@section('content')
<div class="bg-white min-h-screen px-6 py-10 text-justify">
    <div class="container mx-auto pt-32 pb-10 bg-white">

        <h2 class="text-3xl font-bold mb-8">tentang produk two28eight</h2>
        <p>produk two28eight di kembangkan pertama kali pada tanggal...</p>
    </div>
</div>
@endsection